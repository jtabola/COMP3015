#include "scenebasic_uniform.h"

#include <cstdio>
#include <cstdlib>

#include <string>
using std::string;

#include <iostream>
using std::cerr;
using std::endl;

#include "helper/glutils.h"
#include "helper/texture.h"

using glm::vec3;
using glm::vec4;
using glm::mat3;
using glm::mat4;

SceneBasic_Uniform::SceneBasic_Uniform(){

}

void SceneBasic_Uniform::initScene()
{
    compile();
    glEnable(GL_DEPTH_TEST);
    model = mat4(1.0f);

    view = glm::lookAt(vec3(1.25f, 0.25f, 2.25f), vec3(0.0f, 0.0f, 0.0f), vec3(0.0f, 1.0f, 0.0f));

    projection = mat4(1.0f);

    prog.setUniform("Lights[0].Position", vec4(5.0f, 3.0f, 1.0f, 1.0f));
    prog.setUniform("Lights[0].Ld", vec3(0.1f, 0.6f, 0.5f));
    prog.setUniform("Lights[0].La", vec3(0.2f, 0.2f, 0.2f));
    prog.setUniform("Lights[0].Ls", vec3(0.2f, 0.1f, 0.1f));

    prog.setUniform("Lights[1].Position", vec4(-5.0f, 3.0f, 1.0f, 1.0f));
    prog.setUniform("Lights[1].Ld", vec3(0.0f, 0.1f, 0.6f));
    prog.setUniform("Lights[1].La", vec3(0.1f, 0.2f, 0.3f));
    prog.setUniform("Lights[1].Ls", vec3(0.0f, 0.1f, 0.2f));

    // Set Fog Color
    prog.setUniform("FogColor", vec3(0.5f, 0.5f, 0.5f));

    // Linear Fog Parameters
    prog.setUniform("FogStart", 1.5f);
    prog.setUniform("FogEnd", 3.5f);

    diffTex = Texture::loadTexture("media/texture/skull_diff.jpg");
    normalMap = Texture::loadTexture("media/texture/skull_normal.jpg");

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, diffTex);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, normalMap);

    objectMesh = ObjMesh::load("media/skull.OBJ", false, true);
}

void SceneBasic_Uniform::compile()
{
	try {
		prog.compileShader("shader/basic_uniform.vert");
		prog.compileShader("shader/basic_uniform.frag");
		prog.link();
		prog.use();
	} catch (GLSLProgramException &e) {
		cerr << e.what() << endl;
		exit(EXIT_FAILURE);
	}
}

void SceneBasic_Uniform::update( float t )
{
    float rotationSpeed = 0.5f;
    float angle = t * rotationSpeed;

    model = glm::rotate(glm::mat4(1.0f), angle, vec3(0.0f, 1.0f, 0.0f));

    setMatrices();
}

void SceneBasic_Uniform::render()
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

    prog.setUniform("Material.Kd", vec3(0.4f, 0.4f, 0.4f));
    prog.setUniform("Material.Ka", vec3(0.5f, 0.5f, 0.5f));
    prog.setUniform("Material.Ks", vec3(0.1f, 0.1f, 0.1f));
    prog.setUniform("Material.Shininess", 10.0f);

    glm::vec4 light0Pos = view * glm::vec4(5.0f, 3.0f, 1.0f, 1.0f);
    glm::vec4 light1Pos = view * glm::vec4(-5.0f, 3.0f, 1.0f, 1.0f);

    prog.setUniform("Lights[0].Position", light0Pos);
    prog.setUniform("Lights[1].Position", light1Pos);

    setMatrices();

    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, diffTex);

    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, normalMap);

    GLint boundTex;
    glGetIntegerv(GL_TEXTURE_BINDING_2D, &boundTex);

    objectMesh->render();

    glDisable(GL_BLEND);

}

void SceneBasic_Uniform::resize(int w, int h)
{
    width = w;
    height = h;
    glViewport(0,0,w,h);
    projection = glm::perspective(glm::radians(70.0f), (float)w / h, 0.3f, 100.0f);
}

void SceneBasic_Uniform::setMatrices() {
    mat4 mv = view * model;
    prog.setUniform("ModelViewMatrix", mv);
    prog.setUniform("NormalMatrix", glm::mat3(vec3(mv[0]), vec3(mv[1]), vec3(mv[2])));
    prog.setUniform("MVP", projection * mv);
}
